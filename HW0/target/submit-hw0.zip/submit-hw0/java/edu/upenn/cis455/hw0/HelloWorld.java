package edu.upenn.cis455.hw0;

public class HelloWorld {
  // TODO: Add your code here
	public static void main(String args[]) {
		System.out.println("*** Author: Kushagra Goel (kgoel96)");
	}
}
